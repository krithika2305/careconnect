import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../services/providers.dart';
import '../auth/login_screen.dart';
import '../shared/prediction_result_screen.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../../services/alzheimers_model_service.dart';

class DoctorDashboard extends ConsumerStatefulWidget {
  const DoctorDashboard({super.key});

  @override
  ConsumerState<DoctorDashboard> createState() => _DoctorDashboardState();
}

class _DoctorDashboardState extends ConsumerState<DoctorDashboard> {
  final AlzheimersModelService _modelService = AlzheimersModelService();
  bool isUploadingMri = false;
  String? mriFileName;

  @override
  void initState() {
    super.initState();
    _modelService.loadModel();
  }

  @override
  void dispose() {
    _modelService.close();
    notesController.dispose();
    super.dispose();
  }
  XFile? mriImageFile;
  String? mriAnalysisResult;
  double? mriConfidence;
  
  bool isSavingNotes = false;
  final notesController = TextEditingController();

  Future<void> logout() async {
    final client = ref.read(supabaseClientProvider);
    await client.auth.signOut();
    ref.invalidate(authSessionProvider);
    ref.invalidate(userProfileProvider);

    if (mounted) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const LoginScreen()),
        (route) => false,
      );
    }
  }

  Future<void> _pickMriImage() async {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library_rounded, color: MedicalTheme.primaryTeal),
              title: const Text('Upload from Gallery'),
              onTap: () async {
                Navigator.of(context).pop();
                final picker = ImagePicker();
                final image = await picker.pickImage(source: ImageSource.gallery);
                if (image != null) {
                  setState(() {
                    mriImageFile = image;
                    mriFileName = image.name;
                    mriAnalysisResult = null;
                    mriConfidence = null;
                  });
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt_rounded, color: MedicalTheme.primaryTeal),
              title: const Text('Take a Photo'),
              onTap: () async {
                Navigator.of(context).pop();
                final picker = ImagePicker();
                final image = await picker.pickImage(source: ImageSource.camera);
                if (image != null) {
                  setState(() {
                    mriImageFile = image;
                    mriFileName = image.name;
                    mriAnalysisResult = null;
                    mriConfidence = null;
                  });
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _runMriAnalysis() async {
    if (mriImageFile == null) return;

    setState(() {
      isUploadingMri = true;
    });

    try {
      // Local AI Inference via TFLite
      final result = await _modelService.predict(mriImageFile!.path);
      
      if (result != null) {
        final predictionStr = result.label;
        final confValue = result.confidence;

        // Upload to Supabase Storage and Insert to mri_predictions
        try {
          final supabase = ref.read(supabaseClientProvider);
          final session = ref.read(authSessionProvider);
          final fileExt = mriImageFile!.path.split('.').last;
          final fileName = '${DateTime.now().millisecondsSinceEpoch}.$fileExt';
          
          await supabase.storage.from('mri_scans').upload(
                fileName,
                File(mriImageFile!.path),
              );
              
          final imageUrl = supabase.storage.from('mri_scans').getPublicUrl(fileName);
          
          if (session != null) {
            await supabase.from('mri_predictions').insert({
              'doctor_id': session.user.id,
              'patient_name': 'Patient Log',
              'image_url': imageUrl,
              'prediction': predictionStr,
              'confidence': confValue,
            });
            ref.invalidate(mriHistoryProvider); // Refresh the history list
          }
        } catch (dbError) {
          debugPrint("Supabase logging error: $dbError");
        }

        setState(() {
          mriAnalysisResult = predictionStr;
          mriConfidence = confValue; 
        });
        
        if (mounted) {
          _navigateToPredictionResult();
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Failed to process image locally. Check shape/model.'),
              backgroundColor: MedicalTheme.accentCoral,
            ),
          );
        }
      }
    } catch (e) {
      debugPrint("Local ML execution error: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error running classification: $e'),
            backgroundColor: MedicalTheme.accentOrange,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          isUploadingMri = false;
        });
      }
    }
  }

  void _navigateToPredictionResult() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PredictionResultScreen(
          imagePath: mriImageFile?.path,
          prediction: mriAnalysisResult ?? "Unknown",
          confidence: mriConfidence ?? 0.0,
        ),
      ),
    );
  }

  Future<void> _saveClinicalNotes() async {
    if (notesController.text.trim().isEmpty) return;

    setState(() {
      isSavingNotes = true;
    });

    // Simulate database write
    await Future.delayed(const Duration(milliseconds: 1500));

    setState(() {
      isSavingNotes = false;
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: const [
              Icon(Icons.check_circle_outline_rounded, color: Colors.white),
              SizedBox(width: 12),
              Text("Consultation notes successfully logged to EHR database."),
            ],
          ),
          backgroundColor: MedicalTheme.accentGreen,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
      );
      notesController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    final profileAsync = ref.watch(userProfileProvider);
    final doctorName = profileAsync.value?['name'] ?? "Clinical Staff";

    return Scaffold(
      backgroundColor: MedicalTheme.lightBg,
      appBar: AppBar(
        title: const Text("Clinician Workspace"),
        backgroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout_outlined),
            onPressed: logout,
            tooltip: "Log Out",
          )
        ],
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Doctor Neurology Department Badge Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.blue.withOpacity(0.08),
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.blue.withOpacity(0.12), width: 1.5),
                      ),
                      child: const Icon(Icons.local_hospital_rounded, color: Colors.blue, size: 30),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Dr. $doctorName",
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: MedicalTheme.darkSlate,
                              letterSpacing: -0.4,
                            ),
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            "Neurology Clinic • CareConnect Medical",
                            style: TextStyle(
                              fontSize: 13,
                              color: MedicalTheme.lightSlate,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 32),

            // Patient Roster Section
            const Text(
              "Assigned Patients Registry",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: MedicalTheme.darkSlate,
                letterSpacing: -0.4,
              ),
            ),
            const SizedBox(height: 16),

            Card(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
                child: Column(
                  children: [
                    _buildPatientTile("John Doe", "74 yrs • Male", "Stage 2 Dementia", MedicalTheme.accentOrange),
                    const Divider(color: Color(0xFFF1F5F9), height: 1),
                    _buildPatientTile("Jane Smith", "68 yrs • Female", "Cognitively Normal", MedicalTheme.accentGreen),
                    const Divider(color: Color(0xFFF1F5F9), height: 1),
                    _buildPatientTile("Robert Johnson", "81 yrs • Male", "Moderate Dementia", MedicalTheme.accentCoral),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 32),

            // AI MRI Diagnostic Upload Section
            const Text(
              "AI MRI Alzheimer Predictor",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: MedicalTheme.darkSlate,
                letterSpacing: -0.4,
              ),
            ),
            const SizedBox(height: 16),

            Card(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: MedicalTheme.primaryTeal.withOpacity(0.08),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.biotech_rounded, color: MedicalTheme.primaryTeal, size: 22),
                        ),
                        const SizedBox(width: 10),
                        const Text(
                          "Axial Slice Telemetry Upload",
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: MedicalTheme.darkSlate),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      "Upload brain MRI scans (3D axial slices) to predict cognitive staging classification via the CareConnect neural networks model interface.",
                      style: TextStyle(color: MedicalTheme.lightSlate, fontSize: 13, height: 1.4),
                    ),
                    const SizedBox(height: 20),

                    // File picker mock with dashed border simulation
                    GestureDetector(
                      onTap: _pickMriImage,
                      child: Container(
                        width: double.infinity,
                        height: 120,
                        decoration: BoxDecoration(
                          color: MedicalTheme.lightBg,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: mriFileName != null ? MedicalTheme.primaryTeal : const Color(0xFFE2E8F0), 
                            width: 1.5,
                          ),
                        ),
                        child: Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                mriFileName != null ? Icons.insert_drive_file_rounded : Icons.cloud_upload_outlined, 
                                color: mriFileName != null ? MedicalTheme.primaryTeal : MedicalTheme.lightSlate, 
                                size: 36,
                              ),
                              const SizedBox(height: 10),
                              Text(
                                mriFileName != null ? mriFileName! : "Click to upload MRI scan file",
                                style: TextStyle(
                                  fontSize: 13, 
                                  color: mriFileName != null ? MedicalTheme.primaryTeal : MedicalTheme.lightSlate, 
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              if (mriFileName != null)
                                Padding(
                                  padding: const EdgeInsets.only(top: 4.0),
                                  child: Text("Ready for scan", style: const TextStyle(fontSize: 11, color: MedicalTheme.lightSlate)),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    if (mriFileName != null) ...[
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: ElevatedButton(
                          onPressed: isUploadingMri ? null : _runMriAnalysis,
                          child: isUploadingMri
                              ? Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: const [
                                    SizedBox(
                                      height: 20,
                                      width: 20,
                                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                                    ),
                                    SizedBox(width: 12),
                                    Text("Running AI Classification Scan..."),
                                  ],
                                )
                              : const Text("Perform AI Classification"),
                        ),
                      ),
                    ]
                  ],
                ),
              ),
            ),
            const SizedBox(height: 32),

            // Emergency Incident Reports
            const Text(
              "Emergency Incident Reports",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: MedicalTheme.darkSlate,
                letterSpacing: -0.4,
              ),
            ),
            const SizedBox(height: 16),
            _buildEmergencyHistorySection(),
            const SizedBox(height: 32),

            // Past AI MRI Predictions
            const Text(
              "Past AI MRI Predictions",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: MedicalTheme.darkSlate,
                letterSpacing: -0.4,
              ),
            ),
            const SizedBox(height: 16),
            _buildMriHistorySection(),
            const SizedBox(height: 32),

            // Clinical Consultation Notes
            const Text(
              "Clinical Consultation Notes",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: MedicalTheme.darkSlate,
                letterSpacing: -0.4,
              ),
            ),
            const SizedBox(height: 16),

            Card(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    TextField(
                      controller: notesController,
                      maxLines: 4,
                      decoration: const InputDecoration(
                        hintText: "Enter diagnosis updates, medications, or caregiver checklists...",
                        labelText: "Consultation Notes Registry",
                        alignLabelWithHint: true,
                      ),
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: MedicalTheme.secondaryMint),
                        onPressed: isSavingNotes ? null : _saveClinicalNotes,
                        child: isSavingNotes
                            ? Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: const [
                                  SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                                  ),
                                  SizedBox(width: 12),
                                  Text("Syncing Notes with EHR DB..."),
                                ],
                              )
                            : const Text("Sync Notes to Database"),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPatientTile(String name, String details, String diagnosis, Color color) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: MedicalTheme.primaryTeal.withOpacity(0.08),
          shape: BoxShape.circle,
        ),
        child: const Icon(Icons.person_outline_rounded, color: MedicalTheme.primaryTeal, size: 24),
      ),
      title: Text(
        name, 
        style: const TextStyle(fontWeight: FontWeight.bold, color: MedicalTheme.darkSlate, fontSize: 15),
      ),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 4.0),
        child: Text(details, style: const TextStyle(fontSize: 12, color: MedicalTheme.lightSlate)),
      ),
      trailing: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08), 
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.16), width: 1),
        ),
        child: Text(
          diagnosis,
          style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  Widget _buildMriHistorySection() {
    final historyAsync = ref.watch(mriHistoryProvider);

    return historyAsync.when(
      data: (records) {
        if (records.isEmpty) {
          return const Card(
            child: Padding(
              padding: EdgeInsets.all(20.0),
              child: Center(
                child: Text(
                  "No past MRI predictions found.",
                  style: TextStyle(color: MedicalTheme.lightSlate),
                ),
              ),
            ),
          );
        }

        return ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: records.length,
          itemBuilder: (context, index) {
            final record = records[index];
            final prediction = record['prediction'] ?? 'Unknown';
            final confidence = record['confidence'] ?? 0.0;
            final dateStr = record['created_at']?.toString() ?? '';
            final formattedDate = dateStr.length >= 10 ? dateStr.substring(0, 10) : 'N/A';
            
            Color statusColor = MedicalTheme.accentOrange;
            if (prediction.toString().toLowerCase().contains('normal') || prediction.toString().toLowerCase().contains('non')) {
              statusColor = MedicalTheme.accentGreen;
            } else if (prediction.toString().toLowerCase().contains('moderate') || prediction.toString().toLowerCase().contains('severe')) {
              statusColor = MedicalTheme.accentCoral;
            }

            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    record['image_url'] ?? '',
                    width: 50,
                    height: 50,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => Container(
                      width: 50,
                      height: 50,
                      color: Colors.grey.shade200,
                      child: const Icon(Icons.image_not_supported_rounded, color: Colors.grey),
                    ),
                  ),
                ),
                title: Text(
                  prediction,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: MedicalTheme.darkSlate),
                ),
                subtitle: Text(
                  "Confidence: ${confidence is num ? confidence.toStringAsFixed(1) : confidence}% • $formattedDate",
                  style: const TextStyle(fontSize: 12, color: MedicalTheme.lightSlate),
                ),
                trailing: Icon(Icons.analytics_rounded, color: statusColor),
              ),
            );
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stack) => Center(child: Text("Error: $error")),
    );
  }

  Widget _buildEmergencyHistorySection() {
    final historyAsync = ref.watch(emergencyHistoryProvider);

    return historyAsync.when(
      data: (records) {
        if (records.isEmpty) {
          return const Card(
            child: Padding(
              padding: EdgeInsets.all(20.0),
              child: Center(
                child: Text(
                  "No emergency incidents logged.",
                  style: TextStyle(color: MedicalTheme.lightSlate),
                ),
              ),
            ),
          );
        }

        return ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: records.length > 5 ? 5 : records.length,
          itemBuilder: (context, index) {
            final record = records[index];
            final alertType = record['alert_type'] ?? 'Unknown Alert';
            final patientName = record['patient_name'] ?? 'Patient';
            final dateStr = record['created_at']?.toString() ?? '';
            final formattedDate = dateStr.length >= 16 ? dateStr.substring(0, 16).replaceFirst('T', ' ') : 'N/A';
            final isResolved = record['status'] == 'RESOLVED';
            
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: isResolved ? MedicalTheme.accentGreen.withOpacity(0.1) : MedicalTheme.accentCoral.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    isResolved ? Icons.check_circle_outline : Icons.warning_amber_rounded,
                    color: isResolved ? MedicalTheme.accentGreen : MedicalTheme.accentCoral,
                  ),
                ),
                title: Text(
                  alertType,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: MedicalTheme.darkSlate),
                ),
                subtitle: Text(
                  "$patientName • $formattedDate",
                  style: const TextStyle(fontSize: 12, color: MedicalTheme.lightSlate),
                ),
                trailing: Text(
                  isResolved ? "RESOLVED" : "ACTIVE",
                  style: TextStyle(
                    color: isResolved ? MedicalTheme.accentGreen : MedicalTheme.accentCoral,
                    fontWeight: FontWeight.bold,
                    fontSize: 11,
                  ),
                ),
              ),
            );
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stack) => Center(child: Text("Error: $error")),
    );
  }
}
