import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../services/providers.dart';
import '../auth/login_screen.dart';
import 'alerts_screen.dart';
import 'patient_status_screen.dart';

class CaregiverDashboard extends ConsumerStatefulWidget {
  const CaregiverDashboard({super.key});

  @override
  ConsumerState<CaregiverDashboard> createState() => _CaregiverDashboardState();
}

class _CaregiverDashboardState extends ConsumerState<CaregiverDashboard> {
  List<dynamic> records = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    fetchPatientData();
  }

  Future<void> fetchPatientData() async {
    final client = ref.read(supabaseClientProvider);
    try {
      final data = await client
          .from('cognitive_tests')
          .select()
          .order('created_at', ascending: false);

      setState(() {
        records = data;
        loading = false;
      });
    } catch (e) {
      setState(() {
        loading = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Database error: $e"),
            backgroundColor: MedicalTheme.accentCoral,
          ),
        );
      }
    }
  }

  Future<void> logout() async {
    final client = ref.read(supabaseClientProvider);
    await client.auth.signOut();
    ref.invalidate(authSessionProvider);
    ref.invalidate(userProfileProvider);

    if (mounted) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const LoginScreen()),
        (route) => false,
      );
    }
  }

  Color getStatusColor(String status) {
    if (status.contains("Normal")) return MedicalTheme.accentGreen;
    if (status.contains("Concern")) return MedicalTheme.accentOrange;
    return MedicalTheme.accentCoral;
  }

  Widget _buildStatusPill(String status) {
    Color baseColor = getStatusColor(status);
    String text = "Unknown";
    if (status.contains("Normal")) text = "Normal";
    else if (status.contains("Concern")) text = "Concern";
    else if (status.contains("High") || status.contains("Delay")) text = "High Risk";

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: baseColor.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: baseColor.withOpacity(0.16), width: 1),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.bold,
          color: baseColor,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final profileAsync = ref.watch(userProfileProvider);
    final caregiverName = profileAsync.value?['name'] ?? "Caregiver";
    final activeAlertsAsync = ref.watch(activeEmergencyAlertsProvider);
    final activeAlerts = activeAlertsAsync.value ?? [];

    final latestRecord = records.isNotEmpty ? records.first : null;
    final latestStatus = latestRecord != null ? latestRecord["ai_status"]?.toString() ?? "Unknown" : "No Patient Data";
    final latestColor = latestRecord != null ? getStatusColor(latestStatus) : Colors.grey;

    // Filter critical tests
    final criticalAlertCount = records.where((r) => 
        r["ai_status"]?.toString().contains("High") == true || r["missed_game"] == 1).length;

    return Scaffold(
      backgroundColor: MedicalTheme.lightBg,
      appBar: AppBar(
        title: const Text("Caregiver Workspace"),
        backgroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout_outlined),
            onPressed: logout,
            tooltip: "Log Out",
          )
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: fetchPatientData,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (activeAlerts.isNotEmpty)
                      _buildEmergencyBanner(activeAlerts.first),

                    // Caregiver Clinical Header
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: MedicalTheme.secondaryMint.withOpacity(0.08),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.supervisor_account_rounded,
                                color: MedicalTheme.secondaryMint,
                                size: 32,
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Welcome, $caregiverName",
                                    style: const TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: MedicalTheme.darkSlate,
                                      letterSpacing: -0.4,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Row(
                                    children: const [
                                      Icon(Icons.person_pin_rounded, size: 14, color: MedicalTheme.lightSlate),
                                      SizedBox(width: 4),
                                      Text(
                                        "Assigned Patient: John Doe",
                                        style: TextStyle(
                                          fontSize: 13,
                                          color: MedicalTheme.lightSlate,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Patient Telemetry Status Banner
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: const Color(0xFFF1F5F9), width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.02),
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          )
                        ],
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: latestColor.withOpacity(0.08),
                              shape: BoxShape.circle,
                              border: Border.all(color: latestColor.withOpacity(0.12), width: 1.5),
                            ),
                            child: Icon(
                              latestStatus.contains("Missed") 
                                  ? Icons.event_busy_rounded 
                                  : Icons.psychology_rounded, 
                              color: latestColor, 
                              size: 28,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      width: 8,
                                      height: 8,
                                      decoration: BoxDecoration(
                                        color: latestColor,
                                        shape: BoxShape.circle,
                                        boxShadow: [
                                          BoxShadow(
                                            color: latestColor.withOpacity(0.4),
                                            blurRadius: 4,
                                            spreadRadius: 1,
                                          )
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 6),
                                    const Text(
                                      "Active Telemetry Status",
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: MedicalTheme.lightSlate,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  latestStatus,
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: latestColor,
                                    letterSpacing: -0.3,
                                  ),
                                ),
                                if (latestRecord != null) ...[
                                  const SizedBox(height: 6),
                                  Text(
                                    "Last logged: ${latestRecord['created_at'].toString().substring(0, 10)} at ${latestRecord['created_at'].toString().substring(11, 16)}",
                                    style: const TextStyle(fontSize: 11, color: MedicalTheme.lightSlate),
                                  ),
                                ],
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 32),

                    // Monitoring Modules Grid
                    const Text(
                      "Patient Safety Metrics",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: MedicalTheme.darkSlate,
                        letterSpacing: -0.4,
                      ),
                    ),
                    const SizedBox(height: 16),

                    GridView.count(
                      crossAxisCount: 2,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      childAspectRatio: 1.05,
                      children: [
                        _buildSafetyCard(
                          icon: Icons.notifications_active_rounded,
                          title: "Safety Alerts",
                          value: criticalAlertCount > 0 ? "$criticalAlertCount Active" : "No Alerts",
                          color: criticalAlertCount > 0 ? MedicalTheme.accentCoral : MedicalTheme.accentGreen,
                          badgeCount: criticalAlertCount,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => AlertsScreen(records: records)),
                            );
                          },
                        ),
                        _buildSafetyCard(
                          icon: Icons.analytics_rounded,
                          title: "Cognitive Profile",
                          value: "Telemetry & Logs",
                          color: MedicalTheme.primaryTeal,
                          badgeCount: 0,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => PatientStatusScreen(records: records)),
                            );
                          },
                        ),
                        _buildSafetyCard(
                          icon: Icons.map_rounded,
                          title: "Geofencing Zone",
                          value: "Inside Safe Area",
                          color: Colors.blue,
                          badgeCount: 0,
                          onTap: () => _showGeofenceDetails(),
                        ),
                        _buildSafetyCard(
                          icon: Icons.watch_rounded,
                          title: "Wearable Device",
                          value: "Fully Synced",
                          color: Colors.purple,
                          badgeCount: 0,
                          onTap: () => _showDeviceDetails(),
                        ),
                      ],
                    ),
                    const SizedBox(height: 32),

                    // History Feed Header
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          "Log History Feed",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: MedicalTheme.darkSlate,
                            letterSpacing: -0.4,
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => PatientStatusScreen(records: records)),
                            );
                          },
                          child: const Text("View All Reports", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),

                    if (records.isEmpty)
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(24.0),
                          child: Center(
                            child: Column(
                              children: const [
                                Icon(Icons.history_toggle_off_rounded, color: MedicalTheme.lightSlate, size: 48),
                                SizedBox(height: 12),
                                Text(
                                  "No testing logs available yet.",
                                  style: TextStyle(color: MedicalTheme.lightSlate),
                                ),
                              ],
                            ),
                          ),
                        ),
                      )
                    else
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: records.length > 5 ? 5 : records.length,
                        itemBuilder: (context, index) {
                          final record = records[index];
                          final status = record["ai_status"]?.toString() ?? "Unknown";
                          final dateStr = record["created_at"]?.toString() ?? "";
                          final formattedDate = dateStr.length >= 10 ? dateStr.substring(0, 10) : "N/A";
                          final timeStr = dateStr.length >= 16 ? dateStr.substring(11, 16) : "N/A";

                          return Card(
                            margin: const EdgeInsets.only(bottom: 12),
                            child: ListTile(
                              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              leading: Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: getStatusColor(status).withOpacity(0.08),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  status.contains("Missed") 
                                      ? Icons.event_busy_rounded 
                                      : Icons.psychology_rounded, 
                                  color: getStatusColor(status),
                                  size: 22,
                                ),
                              ),
                              title: Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      status.split('–').first.split(' - ').first.trim(),
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14,
                                        color: MedicalTheme.darkSlate,
                                      ),
                                    ),
                                  ),
                                  _buildStatusPill(status),
                                ],
                              ),
                              subtitle: Padding(
                                padding: const EdgeInsets.only(top: 4.0),
                                child: Text(
                                  record['missed_game'] == 1
                                      ? "Skipped assessment test prompt."
                                      : "Test speed: ${record['duration']}s • Registered: $timeStr",
                                  style: const TextStyle(fontSize: 11, color: MedicalTheme.lightSlate),
                                ),
                              ),
                              trailing: Text(
                                formattedDate,
                                style: const TextStyle(fontSize: 11, color: MedicalTheme.lightSlate, fontWeight: FontWeight.bold),
                              ),
                            ),
                          );
                        },
                      ),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildSafetyCard({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
    required int badgeCount,
    required VoidCallback onTap,
  }) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: color.withOpacity(0.12), width: 1.5),
                    ),
                    child: Icon(icon, color: color, size: 26),
                  ),
                  if (badgeCount > 0)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: MedicalTheme.accentCoral,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        "$badgeCount",
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 13,
                      color: MedicalTheme.lightSlate,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: badgeCount > 0 ? MedicalTheme.accentCoral : color,
                      letterSpacing: -0.3,
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  void _showGeofenceDetails() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28.0, vertical: 32.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                alignment: Alignment.center,
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(2)),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                "Patient Safety Boundaries",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: MedicalTheme.darkSlate,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                "Geofencing boundaries synced with patient wearable hardware",
                style: TextStyle(color: MedicalTheme.lightSlate, fontSize: 13),
              ),
              const SizedBox(height: 24),
              Card(
                child: ListTile(
                  leading: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: MedicalTheme.primaryTeal.withOpacity(0.08),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.home_rounded, color: MedicalTheme.primaryTeal),
                  ),
                  title: const Text("Home Safezone (500m radius)", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  subtitle: const Text("Status: Active Geofence"),
                  trailing: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: MedicalTheme.accentGreen.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: MedicalTheme.accentGreen.withOpacity(0.16)),
                    ),
                    child: const Text(
                      "SAFE",
                      style: TextStyle(color: MedicalTheme.accentGreen, fontWeight: FontWeight.bold, fontSize: 11),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: MedicalTheme.accentOrange.withOpacity(0.08),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.location_on_rounded, color: MedicalTheme.accentOrange),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              "Telemetry Coordinates",
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: MedicalTheme.darkSlate),
                            ),
                            SizedBox(height: 4),
                            Text(
                              "Lat: 37.7749° N • Lng: 122.4194° W",
                              style: TextStyle(fontSize: 12, color: MedicalTheme.lightSlate),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        );
      },
    );
  }

  void _showDeviceDetails() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28.0, vertical: 32.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                alignment: Alignment.center,
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(2)),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                "IoT Wearable Health Ring",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: MedicalTheme.darkSlate,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                "Telemetry status of active connected peripheral hardware",
                style: TextStyle(color: MedicalTheme.lightSlate, fontSize: 13),
              ),
              const SizedBox(height: 24),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      _buildTelemetryRow("Hardware Model", "BioRing V3 Clinician"),
                      const Divider(color: Color(0xFFF1F5F9)),
                      _buildTelemetryRow("Bluetooth BLE Link", "Connected & Syncing"),
                      const Divider(color: Color(0xFFF1F5F9)),
                      _buildTelemetryRow("Battery Health", "87% (Stable)"),
                      const Divider(color: Color(0xFFF1F5F9)),
                      _buildTelemetryRow("Telemetry Rate", "Every 5 minutes"),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTelemetryRow(String title, String val) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: const TextStyle(color: MedicalTheme.lightSlate, fontWeight: FontWeight.w500, fontSize: 14)),
          Text(val, style: const TextStyle(fontWeight: FontWeight.bold, color: MedicalTheme.darkSlate, fontSize: 14)),
        ],
      ),
    );
  }

  Widget _buildEmergencyBanner(dynamic alert) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 24),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: MedicalTheme.accentCoral,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: MedicalTheme.accentCoral.withOpacity(0.3),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.warning_amber_rounded, color: Colors.white, size: 32),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "ACTIVE ${alert['alert_type'] ?? 'EMERGENCY'}",
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 18,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "Patient: ${alert['patient_name'] ?? 'Unknown'}",
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (alert['latitude'] != null && alert['longitude'] != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 16.0),
              child: Row(
                children: [
                  const Icon(Icons.location_on_rounded, color: Colors.white70, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    "Location: ${alert['latitude']}, ${alert['longitude']}",
                    style: const TextStyle(color: Colors.white, fontSize: 13),
                  ),
                ],
              ),
            ),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: MedicalTheme.accentCoral,
              ),
              onPressed: () => _resolveAlert(alert['id']),
              child: const Text("MARK AS RESOLVED", style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          )
        ],
      ),
    );
  }

  Future<void> _resolveAlert(String alertId) async {
    final client = ref.read(supabaseClientProvider);
    try {
      await client
          .from('emergency_alerts')
          .update({'status': 'RESOLVED', 'resolved_at': DateTime.now().toUtc().toIso8601String()})
          .eq('id', alertId);
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Emergency Alert Resolved."), backgroundColor: MedicalTheme.accentGreen),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Failed to resolve: $e"), backgroundColor: MedicalTheme.accentCoral),
        );
      }
    }
  }
}