import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../patient/patient_dashboard.dart';
import '../caregiver/caregiver_dashboard.dart';
import '../doctor/doctor_dashboard.dart';

class RoleSelectionScreen extends StatelessWidget {
  const RoleSelectionScreen({super.key});

  Widget _buildRoleCard({
    required BuildContext context,
    required IconData icon,
    required String title,
    required String description,
    required Widget targetScreen,
    required Color color,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16.0),
      child: InkWell(
        onTap: () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => targetScreen),
          );
        },
        borderRadius: BorderRadius.circular(24),
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: color.withOpacity(0.12), width: 1.5),
                ),
                child: Icon(icon, size: 36, color: color),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: MedicalTheme.darkSlate,
                        letterSpacing: -0.4,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      description,
                      style: const TextStyle(
                        fontSize: 13,
                        color: MedicalTheme.lightSlate,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: MedicalTheme.lightBg,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.arrow_forward_rounded,
                  size: 16,
                  color: MedicalTheme.primaryTeal,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MedicalTheme.lightBg,
      appBar: AppBar(
        title: const Text("Select Workspace"),
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Choose Your View",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: MedicalTheme.darkSlate,
                letterSpacing: -0.6,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              "Select how you want to experience CareConnect. Access features tailored specifically to your needs.",
              style: TextStyle(
                fontSize: 14,
                color: MedicalTheme.lightSlate,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 32),
            Expanded(
              child: ListView(
                physics: const BouncingScrollPhysics(),
                children: [
                  _buildRoleCard(
                    context: context,
                    icon: Icons.psychology_outlined,
                    title: "Patient Dashboard",
                    description: "Access cognitive exercises, view your medical charts, track performance parameters, and issue emergency notifications.",
                    targetScreen: const PatientDashboard(),
                    color: MedicalTheme.primaryTeal,
                  ),
                  _buildRoleCard(
                    context: context,
                    icon: Icons.favorite_border_rounded,
                    title: "Caregiver Dashboard",
                    description: "Monitor patient activity logs, track cognitive test results, toggle safety boundaries, and receive instant alert notifications.",
                    targetScreen: const CaregiverDashboard(),
                    color: MedicalTheme.secondaryMint,
                  ),
                  _buildRoleCard(
                    context: context,
                    icon: Icons.local_hospital_outlined,
                    title: "Doctor Dashboard",
                    description: "Review patient trends, consult medical rosters, run AI MRI diagnostic uploads, and annotate clinical guidance notes.",
                    targetScreen: const DoctorDashboard(),
                    color: Colors.indigo,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}