import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:image/image.dart' as img;

class MriPredictionResult {
  final String label;
  final double confidence;

  MriPredictionResult(this.label, this.confidence);
}

class AlzheimersModelService {
  Interpreter? _interpreter;

  // ==========================================
  // CONFIGURATION: UPDATE THESE FOR YOUR MODEL
  // ==========================================
  
  // Input dimensions are automatically inferred from the model tensor
  
  // Replace with your model's actual class labels
  // Common Alzheimer's MRI classes:
  static const List<String> classes = [
    "Mild Demented", 
    "Moderate Demented", 
    "Non Demented", 
    "Very Mild Demented"
  ];

  static const String modelPath = 'assets/models/alzheimers_model.tflite';

  Future<void> loadModel() async {
    try {
      _interpreter = await Interpreter.fromAsset(modelPath);
      print('Model loaded successfully');
      
      // Helpful debug prints to verify model requirements
      print('Input shape: ${_interpreter?.getInputTensor(0).shape}');
      print('Output shape: ${_interpreter?.getOutputTensor(0).shape}');
    } catch (e) {
      print('Failed to load model: $e');
    }
  }

  /// Runs prediction on an image file path
  Future<MriPredictionResult?> predict(String imagePath) async {
    if (_interpreter == null) {
      print('Interpreter not initialized. Call loadModel() first.');
      return null;
    }

    try {
      // 1. Read and decode the image
      File file = File(imagePath);
      Uint8List imageBytes = await file.readAsBytes();
      img.Image? originalImage = img.decodeImage(imageBytes);

      if (originalImage == null) {
        print('Failed to decode image');
        return null;
      }

      // Dynamically get input shape [batch, height, width, channels]
      var inputShape = _interpreter!.getInputTensor(0).shape;
      int inputHeight = inputShape[1];
      int inputWidth = inputShape[2];
      int inputChannels = inputShape[3];

      // 2. Preprocess the image
      img.Image resizedImage = img.copyResize(originalImage, width: inputWidth, height: inputHeight);
      
      // Convert to float32 (Assuming model uses float32 normalized to 0.0 - 1.0)
      var inputBytes = Float32List(1 * inputHeight * inputWidth * inputChannels);
      var buffer = Float32List.view(inputBytes.buffer);
      
      int pixelIndex = 0;
      for (int y = 0; y < inputHeight; y++) {
        for (int x = 0; x < inputWidth; x++) {
          var pixel = resizedImage.getPixel(x, y);
          // Normalize RGB values (0-255) to (0.0-1.0)
          if (inputChannels == 3) {
            buffer[pixelIndex++] = pixel.r / 255.0; 
            buffer[pixelIndex++] = pixel.g / 255.0; 
            buffer[pixelIndex++] = pixel.b / 255.0; 
          } else if (inputChannels == 1) {
            // Grayscale
            double gray = (pixel.r + pixel.g + pixel.b) / (3.0 * 255.0);
            buffer[pixelIndex++] = gray;
          }
        }
      }
      
      // Reshape the input array to match the model shape
      var inputData = inputBytes.buffer.asFloat32List().reshape([1, inputHeight, inputWidth, inputChannels]);

      // 3. Prepare the output buffer
      var outputData = List.filled(1 * classes.length, 0.0).reshape([1, classes.length]);

      // 4. Run inference
      _interpreter!.run(inputData, outputData);

      // 5. Post-process the result to get the prediction
      List<double> probabilities = (outputData[0] as List).cast<double>();
      
      // Find the class with the highest probability
      double maxProb = 0.0;
      int maxIndex = -1;
      for (int i = 0; i < probabilities.length; i++) {
        if (probabilities[i] > maxProb) {
          maxProb = probabilities[i];
          maxIndex = i;
        }
      }

      if (maxIndex != -1) {
        return MriPredictionResult(classes[maxIndex], maxProb * 100);
      }

      return null;
    } catch (e) {
      print('Error during prediction: $e');
      return null;
    }
  }

  void close() {
    _interpreter?.close();
  }
}
