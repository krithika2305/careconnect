import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Provider for Supabase client
final supabaseClientProvider = Provider<SupabaseClient>((ref) {
  return Supabase.instance.client;
});

/// Provider for Supabase Authentication State
final authStateProvider = StreamProvider<AuthState>((ref) {
  final client = ref.watch(supabaseClientProvider);
  return client.auth.onAuthStateChange;
});

/// Provider for the current user's session
final authSessionProvider = Provider<Session?>((ref) {
  final authState = ref.watch(authStateProvider).value;
  return authState?.session ?? Supabase.instance.client.auth.currentSession;
});

/// Provider to fetch and cache user role and profile details
final userProfileProvider = FutureProvider<Map<String, dynamic>?>((ref) async {
  final session = ref.watch(authSessionProvider);
  if (session == null) return null;

  final client = ref.read(supabaseClientProvider);
  try {
    final response = await client
        .from('users')
        .select()
        .eq('id', session.user.id)
        .maybeSingle();
    return response;
  } catch (e) {
    return null;
  }
});

/// Cognitive test records provider
final cognitiveHistoryProvider = FutureProvider<List<dynamic>>((ref) async {
  final session = ref.watch(authSessionProvider);
  if (session == null) return [];

  final client = ref.read(supabaseClientProvider);
  try {
    final data = await client
        .from('cognitive_tests')
        .select()
        .eq('user_id', session.user.id)
        .order('created_at', ascending: true);
    return data;
  } catch (e) {
    return [];
  }
});

/// MRI Prediction History provider
final mriHistoryProvider = FutureProvider<List<dynamic>>((ref) async {
  final session = ref.watch(authSessionProvider);
  if (session == null) return [];

  final client = ref.read(supabaseClientProvider);
  try {
    final data = await client
        .from('mri_predictions')
        .select()
        .eq('doctor_id', session.user.id)
        .order('created_at', ascending: false);
    return data;
  } catch (e) {
    return [];
  }
});

/// Active Emergency Alerts Stream Provider (For Caregivers)
final activeEmergencyAlertsProvider = StreamProvider<List<dynamic>>((ref) {
  final client = ref.watch(supabaseClientProvider);
  return client
      .from('emergency_alerts')
      .stream(primaryKey: ['id'])
      .eq('status', 'ACTIVE')
      .order('created_at', ascending: false);
});

/// Emergency Alert History Provider (For Doctors)
final emergencyHistoryProvider = FutureProvider<List<dynamic>>((ref) async {
  final client = ref.read(supabaseClientProvider);
  try {
    final data = await client
        .from('emergency_alerts')
        .select()
        .order('created_at', ascending: false);
    return data;
  } catch (e) {
    return [];
  }
});
