import 'package:flutter/material.dart';

class MedicalTheme {
  // Premium Modern Healthcare Color Palette
  static const Color primaryTeal = Color(0xFF2563EB); // Royal Medical Blue
  static const Color secondaryMint = Color(0xFF0EA5E9); // Tech Cyan
  static const Color lightBg = Color(0xFFF8FAFC); // Clean Slate Blue White
  static const Color accentCoral = Color(0xFFEF4444); // Alert Red
  static const Color accentOrange = Color(0xFFF59E0B); // Warning Amber
  static const Color accentGreen = Color(0xFF10B981); // Success Emerald
  static const Color darkSlate = Color(0xFF0F172A); // Carbon Slate Text
  static const Color lightSlate = Color(0xFF64748B); // Slate Gray Secondary

  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: lightBg,
      colorScheme: const ColorScheme.light(
        primary: primaryTeal,
        secondary: secondaryMint,
        error: accentCoral,
        background: lightBg,
        surface: Colors.white,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        foregroundColor: darkSlate,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
          color: darkSlate,
          fontSize: 18,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.5,
        ),
        iconTheme: IconThemeData(color: darkSlate),
      ),
      textTheme: const TextTheme(
        headlineLarge: TextStyle(color: darkSlate, fontSize: 28, fontWeight: FontWeight.bold, letterSpacing: -0.8),
        headlineMedium: TextStyle(color: darkSlate, fontSize: 22, fontWeight: FontWeight.w700, letterSpacing: -0.5),
        titleLarge: TextStyle(color: darkSlate, fontSize: 18, fontWeight: FontWeight.w600, letterSpacing: -0.3),
        bodyLarge: TextStyle(color: darkSlate, fontSize: 15, height: 1.5),
        bodyMedium: TextStyle(color: lightSlate, fontSize: 13, height: 1.4),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: primaryTeal, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: accentCoral, width: 1),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryTeal,
          foregroundColor: Colors.white,
          elevation: 0,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.2,
          ),
        ),
      ),
      cardTheme: CardThemeData(
        color: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: const BorderSide(color: Color(0xFFF1F5F9), width: 1.5),
        ),
      ),
    );
  }
}

