import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../core/theme.dart';
import '../../services/providers.dart';
import '../auth/login_screen.dart';
import 'cognitive_history_screen.dart';

class PatientDashboard extends ConsumerStatefulWidget {
  const PatientDashboard({super.key});

  @override
  ConsumerState<PatientDashboard> createState() => _PatientDashboardState();
}

class _PatientDashboardState extends ConsumerState<PatientDashboard> {
  bool gameStarted = false;
  int secondsElapsed = 0;
  Timer? timer;
  bool isDispatchingSOS = false;

  int playHour = 0;
  int duration = 0;
  int missedGame = 0;
  int tapCount = 0;
  int requiredTaps = 5;

  String lastStatus = "Normal Cognitive Activity";

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  void startGame() {
    playHour = DateTime.now().hour;
    setState(() {
      gameStarted = true;
      secondsElapsed = 0;
      tapCount = 0;
    });

    timer?.cancel();
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      setState(() {
        secondsElapsed++;
      });
    });
  }

  void registerTap() {
    if (!gameStarted) return;

    setState(() {
      tapCount++;
    });

    if (tapCount >= requiredTaps) {
      finishGame();
    }
  }

  void finishGame() {
    timer?.cancel();
    duration = secondsElapsed;
    missedGame = 0;
    sendPrediction();
  }

  void skipGame() {
    timer?.cancel();
    playHour = DateTime.now().hour;
    duration = 0;
    missedGame = 1;
    sendPrediction();
  }

  Future<void> sendPrediction() async {
    final url = Uri.parse("http://10.0.2.2:5000/predict");
    final body = {
      "play_hour": playHour,
      "duration": duration,
      "missed_game": missedGame
    };

    String status;

    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(body),
      ).timeout(const Duration(seconds: 4));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        status = data["status"];
      } else {
        status = generateFallbackPrediction();
      }
    } catch (e) {
      status = generateFallbackPrediction();
    }

    setState(() {
      lastStatus = status;
      gameStarted = false;
    });

    await saveResult(status);
    ref.invalidate(cognitiveHistoryProvider); // Refresh history provider

    if (mounted) {
      _showResultModal(status);
    }
  }

  String generateFallbackPrediction() {
    if (missedGame == 1) {
      return "High Risk – Missed Cognitive Test";
    }
    if (duration < 5) {
      return "Normal Cognitive Activity";
    }
    if (duration < 15) {
      return "Mild Cognitive Concern";
    }
    return "High Risk Cognitive Delay";
  }

  Future<void> saveResult(String status) async {
    final client = ref.read(supabaseClientProvider);
    final user = client.auth.currentUser;

    if (user == null) return;

    try {
      await client.from('cognitive_tests').insert({
        "user_id": user.id,
        "play_hour": playHour,
        "duration": duration,
        "missed_game": missedGame,
        "ai_status": status
      });
    } catch (e) {
      // Handle db write failure gracefully
    }
  }

  Future<void> sendEmergencyAlert() async {
    if (isDispatchingSOS) return;
    
    setState(() {
      isDispatchingSOS = true;
    });

    try {
      var status = await Permission.locationWhenInUse.status;
      if (status.isDenied) {
        status = await Permission.locationWhenInUse.request();
      }

      double? lat;
      double? lng;

      if (status.isGranted) {
        Position position = await Geolocator.getCurrentPosition(
            desiredAccuracy: LocationAccuracy.high);
        lat = position.latitude;
        lng = position.longitude;
      }

      final client = ref.read(supabaseClientProvider);
      final session = ref.read(authSessionProvider);
      final profileAsync = ref.read(userProfileProvider);
      final patientName = profileAsync.value?['name'] ?? 'Patient';

      if (session != null) {
        await client.from('emergency_alerts').insert({
          'patient_id': session.user.id,
          'patient_name': patientName,
          'alert_type': 'SOS Emergency',
          'status': 'ACTIVE',
          'latitude': lat,
          'longitude': lng,
        });
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: const [
                Icon(Icons.warning_amber_rounded, color: Colors.white, size: 24),
                SizedBox(width: 12),
                Expanded(
                  child: Text(
                    "SOS Emergency Alert dispatched to clinic & caregiver contacts.",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            backgroundColor: MedicalTheme.accentCoral,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            duration: const Duration(seconds: 4),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Failed to dispatch alert: $e"),
            backgroundColor: MedicalTheme.accentCoral,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          isDispatchingSOS = false;
        });
      }
    }
  }

  Color getStatusColor() {
    if (lastStatus.contains("Normal")) return MedicalTheme.accentGreen;
    if (lastStatus.contains("Concern")) return MedicalTheme.accentOrange;
    return MedicalTheme.accentCoral;
  }

  Future<void> logout() async {
    final client = ref.read(supabaseClientProvider);
    await client.auth.signOut();
    ref.invalidate(authSessionProvider);
    ref.invalidate(userProfileProvider);

    if (mounted) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const LoginScreen()),
        (route) => false,
      );
    }
  }

  void _showResultModal(String status) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: getStatusColor().withOpacity(0.08),
                  shape: BoxShape.circle,
                  border: Border.all(color: getStatusColor().withOpacity(0.16), width: 2),
                ),
                child: Icon(
                  Icons.psychology_rounded,
                  size: 56,
                  color: getStatusColor(),
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                "Assessment Logged",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: MedicalTheme.darkSlate,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                status,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: getStatusColor(),
                ),
              ),
              const SizedBox(height: 12),
              Text(
                "Completed in $duration seconds. Classification synchronized to clinic charts.",
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 13,
                  color: MedicalTheme.lightSlate,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Done"),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final profileAsync = ref.watch(userProfileProvider);
    final userName = profileAsync.value?['name'] ?? "Patient";

    return Scaffold(
      backgroundColor: MedicalTheme.lightBg,
      appBar: AppBar(
        title: const Text("CareConnect Home"),
        backgroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout_rounded),
            onPressed: logout,
            tooltip: "Log Out",
          )
        ],
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Welcome Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: MedicalTheme.primaryTeal.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Icon(
                    Icons.face_retouching_natural_rounded,
                    color: MedicalTheme.primaryTeal,
                    size: 32,
                  ),
                ),
                const SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Hello, $userName",
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: MedicalTheme.darkSlate,
                        letterSpacing: -0.5,
                      ),
                    ),
                    const Text(
                      "Let's track your cognitive health today.",
                      style: TextStyle(
                        fontSize: 13,
                        color: MedicalTheme.lightSlate,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 28),

            // Health Status Banner
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: const Color(0xFFF1F5F9), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.02),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  )
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 6,
                    height: 52,
                    decoration: BoxDecoration(
                      color: getStatusColor(),
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Mental Activity Status",
                          style: TextStyle(
                            fontSize: 12,
                            color: MedicalTheme.lightSlate,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          lastStatus,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: getStatusColor(),
                            letterSpacing: -0.3,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: getStatusColor().withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.circle,
                          size: 10,
                          color: getStatusColor(),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          "Live Status",
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: getStatusColor(),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Main Grid Actions
            const Text(
              "Self-Care Modules",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: MedicalTheme.darkSlate,
                letterSpacing: -0.4,
              ),
            ),
            const SizedBox(height: 16),

            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              childAspectRatio: 1.05,
              children: [
                _buildGridCard(
                  icon: Icons.psychology_rounded,
                  title: "Cognitive Test",
                  subtitle: "Daily Tap Challenge",
                  color: MedicalTheme.primaryTeal,
                  onTap: () {
                    startGame();
                    _showGameModal();
                  },
                ),
                _buildGridCard(
                  icon: Icons.analytics_rounded,
                  title: "Trend Charts",
                  subtitle: "View history logs",
                  color: MedicalTheme.secondaryMint,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const CognitiveHistoryScreen(),
                      ),
                    );
                  },
                ),
                _buildGridCard(
                  icon: Icons.favorite_rounded,
                  title: "Vitals Tracker",
                  subtitle: "Bluetooth BLE Sync",
                  color: Colors.indigo,
                  onTap: () => _showVitalsInfo(),
                ),
                _buildGridCard(
                  icon: isDispatchingSOS ? Icons.hourglass_empty_rounded : Icons.warning_rounded,
                  title: isDispatchingSOS ? "Dispatching..." : "SOS Alert",
                  subtitle: isDispatchingSOS ? "Connecting to clinic" : "Tap for Emergency",
                  color: MedicalTheme.accentCoral,
                  onTap: sendEmergencyAlert,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGridCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: color.withOpacity(0.12), width: 1.5),
                ),
                child: Icon(icon, color: color, size: 28),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: MedicalTheme.darkSlate,
                      letterSpacing: -0.3,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      fontSize: 11,
                      color: MedicalTheme.lightSlate,
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  void _showGameModal() {
    showModalBottomSheet(
      context: context,
      isDismissible: false,
      enableDrag: false,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            final percent = (tapCount / requiredTaps).clamp(0.0, 1.0);
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 28.0, vertical: 32.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade200,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 24),
                  const Icon(Icons.bolt_rounded, size: 48, color: MedicalTheme.primaryTeal),
                  const SizedBox(height: 12),
                  const Text(
                    "Cognitive Action Test",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: MedicalTheme.darkSlate,
                      letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "Tap the trigger button as rapidly as possible. This telemetry tracks reaction duration speeds.",
                    textAlign: TextAlign.center,
                    style: TextStyle(color: MedicalTheme.lightSlate, fontSize: 13, height: 1.4),
                  ),
                  const SizedBox(height: 24),

                  // Game stats indicator
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: MedicalTheme.lightBg,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Column(
                          children: [
                            const Text("Duration", style: TextStyle(color: MedicalTheme.lightSlate, fontSize: 11, fontWeight: FontWeight.bold)),
                            const SizedBox(height: 4),
                            Text("$secondsElapsed s", style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: MedicalTheme.darkSlate)),
                          ],
                        ),
                        Container(width: 1.5, height: 32, color: Colors.grey.shade200),
                        Column(
                          children: [
                            const Text("Taps Registered", style: TextStyle(color: MedicalTheme.lightSlate, fontSize: 11, fontWeight: FontWeight.bold)),
                            const SizedBox(height: 4),
                            Text("$tapCount / $requiredTaps", style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: MedicalTheme.primaryTeal)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Linear Progress bar
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: percent,
                      minHeight: 8,
                      color: MedicalTheme.primaryTeal,
                      backgroundColor: Colors.grey.shade100,
                    ),
                  ),
                  const SizedBox(height: 32),

                  // Interactive Tapping Button
                  SizedBox(
                    width: double.infinity,
                    height: 64,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: MedicalTheme.primaryTeal,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                      ),
                      onPressed: () {
                        registerTap();
                        setModalState(() {});
                        if (tapCount >= requiredTaps) {
                          Navigator.pop(context);
                        }
                      },
                      child: const Text(
                        "TAP HERE",
                        style: TextStyle(fontSize: 18, letterSpacing: 1.5, fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextButton(
                    onPressed: () {
                      skipGame();
                      Navigator.pop(context);
                    },
                    child: const Text("Skip & Record Delay", style: TextStyle(color: MedicalTheme.accentCoral, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _showVitalsInfo() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28.0, vertical: 32.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                alignment: Alignment.center,
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(2)),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                "Wearable Vitals Status",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: MedicalTheme.darkSlate,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                "Data synchronized via Bluetooth Medical BLE Ring telemetry",
                style: TextStyle(color: MedicalTheme.lightSlate, fontSize: 13),
              ),
              const SizedBox(height: 24),
              _buildVitalRow(Icons.favorite_rounded, "Heart Rate", "72 bpm", Colors.red),
              const Divider(height: 1, color: Color(0xFFF1F5F9)),
              _buildVitalRow(Icons.nights_stay_rounded, "Sleep Duration", "7.8 hrs", Colors.blue),
              const Divider(height: 1, color: Color(0xFFF1F5F9)),
              _buildVitalRow(Icons.insights_rounded, "Blood Oxygen", "98%", Colors.teal),
              const SizedBox(height: 16),
            ],
          ),
        );
      },
    );
  }

  Widget _buildVitalRow(IconData icon, String title, String value, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 14.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.08),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              const SizedBox(width: 14),
              Text(
                title,
                style: const TextStyle(fontWeight: FontWeight.w600, color: MedicalTheme.darkSlate, fontSize: 15),
              ),
            ],
          ),
          Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: MedicalTheme.darkSlate),
          ),
        ],
      ),
    );
  }
}